# ASTA Africa Technical Boot Camp

A responsive sales landing page and Node/Express integration starter for the ASTA Africa Technical Boot Camp.

## Important payment and production notes

- The current checkout integration uses **Paystack** on the server. Paystack test mode is the recommended first step.
- The supplied OPay account is shown as a **manual bank-transfer option**. This is not an automated OPay payment API integration. Participants who choose it receive a pending registration; an organiser must check the payment independently before confirming the place.
- No payment is simulated. A browser redirect alone is never treated as proof of payment.
- Registrations are stored in an in-memory `Map` for demonstration. This data disappears whenever the server restarts. **Before taking real payments, connect a persistent database** (for example PostgreSQL) and implement organiser/admin access controls.
- Configure Paystack webhooks to `https://YOUR-DOMAIN/api/paystack/webhook`. Use HTTPS in production.
- Email/SMS confirmation is not wired up. Add a trusted email provider and send confirmations only after the server verifies payment.
- The registration form includes basic validation and the API uses rate limiting and security headers. Have the finished deployment reviewed and tested before accepting real payments.

## 1. Run locally

Requirements: Node.js 18 or newer and npm.

```bash
npm install
cp .env.example .env
```

On Windows PowerShell, use `Copy-Item .env.example .env` instead of `cp`.

Edit `.env` and add your Paystack **test** secret key. Then run:

```bash
npm run dev
```

Open `http://localhost:3000`.

Without a Paystack key, online checkout will return a clear configuration error. Manual transfer registration can still be tested, but it will remain pending and will not be marked paid automatically.

## 2. Configure Paystack

1. Create or sign in to your Paystack merchant account and complete the required business verification.
2. In the Paystack dashboard, use the **test** API keys first.
3. Copy the test secret key into `PAYSTACK_SECRET_KEY` in `.env`. Never expose this key in frontend files or commit `.env`.
4. Set `PAYSTACK_CALLBACK_URL` to your public HTTPS callback URL once deployed.
5. Set the webhook URL in your Paystack dashboard to `https://YOUR-DOMAIN/api/paystack/webhook`.
6. Test successful, abandoned, failed, and repeated callback/webhook scenarios before switching to live credentials.
7. When ready and approved, replace the test secret key with the live secret key in your hosting provider's secret/environment-variable settings. Do not put live keys in source code.

The backend verifies transaction reference, successful status, exact amount (₦5,000 / 500,000 kobo), and currency (NGN). Webhook signatures are checked using HMAC SHA-512 and duplicate event references are guarded. For a full production system, also persist webhook event IDs and transactions in a database with unique constraints.

### Flutterwave alternative

This project does not include Flutterwave code. If choosing Flutterwave instead, implement a separate server-side transaction initialization and verification flow using Flutterwave's current official API documentation. Verify transaction ID/reference, status, amount, and NGN currency server-side. Do not simply change the frontend label or treat a redirect as proof.

## 3. OPay manual transfer option

The current manual transfer panel uses the details supplied for the project:

- Bank: OPay
- Account name: Ruth Okwuchukwu Maduagwu
- Account number: 7056073043
- Amount: ₦5,000

The website creates a pending registration reference. The participant is directed to WhatsApp to submit proof. An organiser must compare the transfer with the actual OPay transaction record and confirm it through a secure admin workflow. This starter has no admin dashboard or manual-payment approval endpoint; do not mark a participant as paid just because they uploaded a screenshot.

## 4. Add or edit boot camp information

Open `public/index.html` and search for the visible text:
- Date: currently December 25th, 2026
- Duration: currently 2 hours
- Platform: Google Meet
- Registration fee: ₦5,000
- Original price: ₦15,000
- Registration deadline: currently undisclosed
- Certificate availability: currently to be confirmed
- Module titles/descriptions: placeholders, replace only with confirmed agenda topics
- Contact email and social media links: placeholders

If changing the fee, update **both** the displayed amounts in `public/index.html` and `PRICE_KOBO` in `server.js`. The server-side amount is authoritative.

The countdown timer was intentionally omitted because a countdown should only be shown when the date, time, and timezone are confirmed. The date currently has no start time or timezone.

## 5. Deploy

Deploy to a Node.js host that supports environment variables and HTTPS (for example, Render, Railway, Fly.io, or a VPS).

1. Upload/push the project to your hosting provider.
2. Set the build/install command to `npm install`.
3. Set the start command to `npm start`.
4. Add `PAYSTACK_SECRET_KEY`, `PAYSTACK_CALLBACK_URL`, and `PORT` as environment variables in the host dashboard.
5. Attach a persistent database and replace the in-memory `Map` in `server.js` with database operations before production.
6. Configure the Paystack webhook URL in the dashboard.
7. Test on the deployed HTTPS domain using Paystack test mode before live mode.

## 6. Connect a domain

1. Purchase a domain from a domain registrar.
2. Add the domain in your hosting provider's dashboard.
3. Add the DNS records supplied by the host (commonly A/AAAA or CNAME records).
4. Wait for DNS propagation and enable the host's SSL/TLS certificate.
5. Update `PAYSTACK_CALLBACK_URL` and the Paystack webhook URL to use the final HTTPS domain.

## 7. Registration management

This starter has no private admin dashboard. In the demo, records are held in memory and can be queried only through the public minimal status endpoint. For a real launch, build:
- A persistent database table for participants, registrations, payments, and webhook events.
- An authenticated admin dashboard with role-based access.
- A manual-transfer reconciliation and approval workflow.
- A unique database constraint on gateway transaction reference.
- Email confirmation after verified payment.
- Privacy retention/deletion controls and restricted access to participant data.

Never publish participant information or payment credentials. Collect only information necessary for the event and publish a privacy notice that accurately describes data handling.

## Project structure

```text
asta-africa-bootcamp/
├── public/
│   ├── index.html
│   ├── style.css
│   ├── script.js
│   ├── payment-result.html
│   └── payment-result.js
├── server.js
├── package.json
├── .env.example
├── .gitignore
└── README.md
```
