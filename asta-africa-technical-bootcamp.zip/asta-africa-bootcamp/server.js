require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const PRICE_KOBO = 500000; // ₦5,000 in kobo
const CURRENCY = 'NGN';

// Security headers. Inline scripts/styles are not used; Google Fonts and Unsplash are allow-listed.
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:", "https://images.unsplash.com"],
      connectSrc: ["'self'", "https://api.paystack.co"],
      frameAncestors: ["'none'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: []
    }
  }
}));
app.use(express.json({
  limit: '20kb',
  verify: (req, res, buffer) => {
    // Preserve the exact request bytes so the Paystack webhook signature can be verified.
    if (req.originalUrl === '/api/paystack/webhook') req.rawBody = Buffer.from(buffer);
  }
}));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }));

const registrations = new Map(); // Demo persistence only. Replace with a real database before production.
const paymentEvents = new Set();

function clean(value, max = 160) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}
function validateParticipant(body) {
  const participant = {
    fullName: clean(body.fullName, 120),
    email: clean(body.email, 160).toLowerCase(),
    phone: clean(body.phone, 30),
    country: clean(body.country, 80),
    occupation: clean(body.occupation, 80),
    education: clean(body.education, 160)
  };
  if (Object.values(participant).some(v => !v)) throw new Error('Please complete every participant field.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(participant.email)) throw new Error('Enter a valid email address.');
  return participant;
}
function newReference(prefix = 'ASTA') {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
}
function paystackHeaders() {
  if (!process.env.PAYSTACK_SECRET_KEY) throw new Error('Online payment is not configured. Please use manual transfer or contact the organiser.');
  return { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`, 'Content-Type': 'application/json' };
}

app.post('/api/registrations', async (req, res) => {
  try {
    const participant = validateParticipant(req.body);
    const paymentMethod = clean(req.body.paymentMethod, 20);
    if (!['paystack', 'transfer'].includes(paymentMethod)) return res.status(400).json({ error: 'Choose a valid payment method.' });

    const reference = newReference();
    const registration = {
      reference, participant, amount: PRICE_KOBO, currency: CURRENCY,
      paymentMethod, status: 'pending', createdAt: new Date().toISOString()
    };
    registrations.set(reference, registration);

    if (paymentMethod === 'transfer') {
      return res.status(201).json({ reference, status: 'pending_payment_verification' });
    }

    const callbackUrl = process.env.PAYSTACK_CALLBACK_URL || `${req.protocol}://${req.get('host')}/payment/callback`;
    const gatewayResponse = await fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST',
      headers: paystackHeaders(),
      body: JSON.stringify({
        email: participant.email,
        amount: PRICE_KOBO,
        currency: CURRENCY,
        reference,
        callback_url: callbackUrl,
        metadata: {
          registration_reference: reference,
          full_name: participant.fullName,
          phone: participant.phone,
          custom_fields: [{ display_name: 'Boot camp', variable_name: 'boot_camp', value: 'ASTA Africa Technical Boot Camp' }]
        }
      })
    });
    const result = await gatewayResponse.json();
    if (!gatewayResponse.ok || !result.status) {
      registrations.delete(reference);
      return res.status(502).json({ error: result.message || 'Unable to start payment. Please try again.' });
    }
    registration.gatewayAccessCode = result.data.access_code;
    res.status(201).json({ reference, authorizationUrl: result.data.authorization_url });
  } catch (error) {
    res.status(400).json({ error: error.message || 'Unable to process registration.' });
  }
});

// Paystack redirects here after checkout. Redirect is NOT proof of payment.
// The browser is sent to a status page; server verification determines the outcome.
app.get('/payment/callback', async (req, res) => {
  const reference = clean(req.query.reference, 100);
  if (!reference) return res.redirect('/payment-result.html?status=missing');
  try {
    const verifyResponse = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: paystackHeaders()
    });
    const verification = await verifyResponse.json();
    const registration = registrations.get(reference);
    if (!verifyResponse.ok || !verification.status || !registration) {
      return res.redirect(`/payment-result.html?status=review&reference=${encodeURIComponent(reference)}`);
    }
    const txn = verification.data;
    const valid = txn.status === 'success' &&
      txn.reference === reference &&
      Number(txn.amount) === PRICE_KOBO &&
      txn.currency === CURRENCY &&
      txn.gateway_response;
    if (valid) {
      registration.status = 'paid';
      registration.paidAt = new Date().toISOString();
      registration.gatewayTransactionId = String(txn.id);
      return res.redirect(`/payment-result.html?status=success&reference=${encodeURIComponent(reference)}`);
    }
    registration.status = 'payment_failed';
    return res.redirect(`/payment-result.html?status=failed&reference=${encodeURIComponent(reference)}`);
  } catch {
    return res.redirect(`/payment-result.html?status=review&reference=${encodeURIComponent(reference)}`);
  }
});

// Webhook: verify Paystack's HMAC signature and then independently verify transaction details.
app.post('/api/paystack/webhook', async (req, res) => {
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return res.sendStatus(503);
  const signature = req.headers['x-paystack-signature'];
  const expected = crypto.createHmac('sha512', secret).update(req.rawBody || Buffer.alloc(0)).digest('hex');
  if (!signature || signature.length !== expected.length ||
      !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return res.sendStatus(401);

  let event;
  try { event = JSON.parse((req.rawBody || Buffer.alloc(0)).toString('utf8')); } catch { return res.sendStatus(400); }
  if (event.event !== 'charge.success' || !event.data?.reference) return res.sendStatus(200);
  const reference = clean(event.data.reference, 100);
  if (paymentEvents.has(reference)) return res.sendStatus(200); // idempotency guard
  try {
    const verifyResponse = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: paystackHeaders()
    });
    const verification = await verifyResponse.json();
    const registration = registrations.get(reference);
    if (verifyResponse.ok && verification.status && registration) {
      const txn = verification.data;
      if (txn.status === 'success' && txn.reference === reference &&
          Number(txn.amount) === PRICE_KOBO && txn.currency === CURRENCY) {
        registration.status = 'paid';
        registration.paidAt = new Date().toISOString();
        registration.gatewayTransactionId = String(txn.id);
        paymentEvents.add(reference);
      }
    }
    return res.sendStatus(200);
  } catch {
    return res.sendStatus(500);
  }
});

// Public status endpoint exposes only minimal registration state.
app.get('/api/registrations/:reference/status', (req, res) => {
  const registration = registrations.get(clean(req.params.reference, 100));
  if (!registration) return res.status(404).json({ error: 'Registration not found.' });
  res.json({ reference: registration.reference, status: registration.status, paidAt: registration.paidAt || null });
});

app.get('/health', (_req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`ASTA Africa site running on http://localhost:${PORT}`));
